package application;

import java.util.List;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * JDK 11, Eclipse 2019-06
 * https://gluonhq.com/products/javafx/
 * https://openjfx.io/openjfx-docs/
 *
 * @author Debra Deppeler
 */
public class Main extends Application {
	// store any command-line arguments that were entered.
	// NOTE: this.getParameters().getRaw() will get these also
	private List<String> args;

	private static final int WINDOW_WIDTH = 300;
	private static final int WINDOW_HEIGHT = 200;
	private static final String APP_TITLE = "Hello World!";
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		// save args example
		args = this.getParameters().getRaw();
			
		// Create a vertical box with Hello labels for each args
        	VBox vbox = new VBox();
        	for (String arg : args) {
        		vbox.getChildren().add(new Label("hello "+arg));
        	}

		// Main layout is Border Pane example (top,left,center,right,bottom)
        	BorderPane root = new BorderPane();

		// Add the vertical box to the center of the root pane
		root.setTop(new Label(APP_TITLE));
        	root.setCenter(vbox);
		Scene mainScene = new Scene(root, WINDOW_WIDTH, WINDOW_HEIGHT);

		// Add the stuff and set the primary stage
        	primaryStage.setTitle(APP_TITLE);
        	primaryStage.setScene(mainScene);
        	primaryStage.show();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		   launch(args);
	}
}
